<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "portfolio"; // corrected database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['signup'])) {
    $name = $_POST['username']; // corrected variable name
    $email = $_POST['email']; // corrected variable name
    $password = $_POST['Password']; // corrected variable name
    $confirm_password = $_POST['Repeat_Password']; // corrected variable name

    // Check if passwords match
    if ($password !== $confirm_password) {
        echo "Passwords do not match!";
        exit();
    }

    // Check if password contains numbers
    if (preg_match('/[0-9]/', $password)) {
        echo "Password should not contain numbers!";
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert data into the database
    $sql = "INSERT INTO login (name, email, password) VALUES ('$name', '$email', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        echo "Signup successful!";

        
       
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} elseif (isset($_POST['login'])) {
    $email = $_POST['Email']; // corrected variable name
    $password = $_POST['Password']; // corrected variable name

    // Retrieve user from the database
    $sql = "SELECT * FROM login WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch user data
        $row = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $row['password'])) {
            echo "Login successful!";
            header("Location: admin_panel.php"); // Redirect to admin panel
            exit();
        } else {
            echo "Invalid email or password!";
        }
    } else {
        echo "Invalid email or password!";
    }
}

$conn->close();
?>
